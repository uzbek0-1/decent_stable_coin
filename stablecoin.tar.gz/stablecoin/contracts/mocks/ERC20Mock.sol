// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @notice Simple mintable ERC20 standing in for WETH/WBTC in local tests.
contract ERC20Mock is ERC20 {
    constructor(string memory name, string memory symbol, address initialAccount, uint256 initialBalance)
        ERC20(name, symbol)
    {
        _mint(initialAccount, initialBalance);
    }

    function mint(address account, uint256 amount) external {
        _mint(account, amount);
    }

    function burn(address account, uint256 amount) external {
        _burn(account, amount);
    }

    function transferInternal(address from, address to, uint256 value) external {
        _transfer(from, to, value);
    }

    function approveInternal(address owner, address spender, uint256 value) external {
        _approve(owner, spender, value);
    }
}
